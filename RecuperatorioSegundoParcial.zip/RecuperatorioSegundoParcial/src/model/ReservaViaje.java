package model;

import java.time.LocalDate;

public class ReservaViaje extends Reserva implements Comparable<ReservaViaje> {

    private String destino;
    private TipoTransporte transporte;

    public ReservaViaje(int id, String pasajero, LocalDate fecha, String destino, TipoTransporte transporte) {
        super(id, pasajero, fecha);
        this.destino = destino;
        this.transporte = transporte;
    }

    @Override
    public String toString() {
        return "ReservaViaje{" + " id=" + getId() + ", pasajero=" + getPasajero() + ", fecha=" + getFecha() + ", destino=" + destino + ", transporte=" + transporte + '}';
    }

    public String getDestino() {
        return destino;
    }

    public TipoTransporte getTransporte() {
        return transporte;
    }

    @Override
    public int compareTo(ReservaViaje other) {
        return this.getFecha().compareTo(other.getFecha());
    }

    @Override
    public String toCSV() {
        return getId() + "," + getPasajero() + "," + getFecha() + "," + destino + "," + transporte;
    }

    public static ReservaViaje fromCSV(String reservaViajeCSV) {
        if (reservaViajeCSV.endsWith("\n")) {
            reservaViajeCSV = reservaViajeCSV.substring(0, reservaViajeCSV.length() - 1);
        }
        String[] valores = reservaViajeCSV.split(",");
        return new ReservaViaje(Integer.parseInt(valores[0]), valores[1], LocalDate.parse(valores[2]), valores[3], TipoTransporte.valueOf(valores[4]));
    }
}
