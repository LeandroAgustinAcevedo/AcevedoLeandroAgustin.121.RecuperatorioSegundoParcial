package config;

import java.nio.file.Path;
import java.nio.file.Paths;

public class AppConfig {

    public static final Path PATH_ARCHIVOS = Paths.get("src/data/");
    public static final Path PATH_BIN = PATH_ARCHIVOS.resolve("reservas.bin");
    public static final Path PATH_CSV = PATH_ARCHIVOS.resolve("reservas.csv");
}
