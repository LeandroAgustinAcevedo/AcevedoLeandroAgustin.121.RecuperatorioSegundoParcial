package service;

public interface CSVSerializable {
    
    String toCSV();
}
