package service;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;
import model.Reserva;

public class GestorReservas<T extends Reserva> implements Gestionable<T> {
    
    List<T> reservas = new ArrayList<>();

    @Override
    public void agregar(T reserva) {
        validarObjetoNulo(reserva);
        reservas.add(reserva);
    }

    @Override
    public void eliminar(int indice) {
        validarIndiceValido(indice);
        validarIndiceEnReservas(indice);
        reservas.remove(indice);
    }

    @Override
    public T obtener(int indice) {
        validarIndiceValido(indice);
        validarIndiceEnReservas(indice);
        return reservas.get(indice);
    }

    @Override
    public void limpiar() {
        reservas.clear();
    }

    @Override
    public void ordenar() {
        ordenar((Comparator<T>) Comparator.naturalOrder());
    }

    @Override
    public void ordenar(Comparator<T> comparador) {
        reservas.sort(comparador);
    }

    @Override
    public List<T> filtrar(Predicate<T> predicador) {
         List<T> toReturn = new ArrayList<>();
         for (T reserva : reservas){
             if (predicador.test(reserva)){
                 toReturn.add(reserva);
             }
         }
         return toReturn;
    }

    @Override
    public void guardarEnBinario(String path) {
        try (ObjectOutputStream salida = new ObjectOutputStream(new FileOutputStream(path))) {
            salida.writeObject(reservas);
        } catch (IOException ex) {
            System.out.println("Ha ocurrido un error al querer guardar en el archivo binario: " + ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeBinario(String path) {
        try (ObjectInputStream entrada = new ObjectInputStream(new FileInputStream(path))) {
            reservas = (List<T>) entrada.readObject();
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Ha ocurrido un error al querer cargar desde el archivo binario: " + ex.getMessage());
        }
    }

    @Override
    public void guardarEnCSV(String path) {
        try (BufferedWriter escritor = new BufferedWriter(new FileWriter(path))) {
            escritor.write("id,pasajero,fecha,destino,transporte\n");
            for (T reserva : reservas){
                escritor.write(reserva.toCSV() + "\n");
            }
        } catch (IOException ex) {
            System.out.println("Ha ocurrido un error al querer guardar en el archivo csv: " + ex.getMessage());
        }
    }

    @Override
    public void cargarDesdeCSV(String path, Function<String, T> funcional) {
        try (BufferedReader lector = new BufferedReader(new FileReader(path))) {
            lector.readLine();
            String linea;
            while ((linea = lector.readLine()) != null){
                reservas.add(funcional.apply(linea));
            }
        } catch (IOException ex) {
            System.out.println("Ha ocurrido un error al querer cargar desde el archivo csv: " + ex.getMessage());
        }
    }

    @Override
    public void mostrarTodos() {
        reservas.forEach(System.out::println);
    }
    
    private void validarObjetoNulo(Object obj){
        if (obj == null){
            throw new IllegalArgumentException("Error. Se esta intentando pasar un argumento nulo.");
        }
    }
    
    private void validarIndiceValido(int indice){
        if(indice < 0){
            throw new IllegalArgumentException("Error. El indice ingresado no es valido.");
        }
    }
    private void validarIndiceEnReservas(int indice){
        if (reservas.size() >= indice){
            throw new IndexOutOfBoundsException("Error. El indice ingresado no se encuentra en reservas.");
        }
    }
    
    
}
