package model;

import java.io.Serializable;
import java.time.LocalDate;
import service.CSVSerializable;

public abstract class Reserva implements Serializable, CSVSerializable{
    
    public static final long serialVersionUID = 1L;
    private int id;
    private String pasajero;
    private LocalDate fecha;

    public Reserva(int id, String pasajero, LocalDate fecha) {
        this.id = id;
        this.pasajero = pasajero;
        this.fecha = fecha;
    }

    public int getId() {
        return id;
    }

    public String getPasajero() {
        return pasajero;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    @Override
    public String toString() {
        return "Reserva{" + "id=" + id + ", pasajero=" + pasajero + ", fecha=" + fecha + '}';
    }
    
}
