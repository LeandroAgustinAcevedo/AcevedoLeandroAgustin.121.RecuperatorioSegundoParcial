package model;

public enum TipoTransporte {
    AVION, TREN, AUTOBUS, BARCO
}
