package service;

import java.util.Comparator;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;

public interface Gestionable<T> {

    void agregar(T item);

    void eliminar(int indice);

    T obtener(int indice);

    void limpiar();

    void ordenar();

    void ordenar(Comparator<T> comparador);

    List<T> filtrar(Predicate<T> predicador);

    void guardarEnBinario(String path);

    void cargarDesdeBinario(String path);

    void guardarEnCSV(String path);

    void cargarDesdeCSV(String path, Function<String, T> funcional);

    void mostrarTodos();
}
